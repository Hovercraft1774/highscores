#Tyler Johnson
#9/21/22
#High Scores


#imports

import math #imported these as a general thing, but didn't use them cause i can't multiply strings like in IDLE.
import random

#variables

player1 = "Holden" #random names who "played" the game. What game? idk, probably life?
player2 = "Scott"
player3 = "Marcus"
bug1 = "Chaos elemental"

score1 = str(10000) #converts the numbers into strings so that they are able to be displayed with the names
score2 = str(6800)
score3 = str(1800)
bugscore = str("999999999999999999999999999999999999999999999999999999") #error, I gotta break it somehow cause
# this is homework

#functions


#main
name = {player1,player3,player2}
score = {score3,score2,score1}
def main():
    print("\t\t\t\t\tHigh Scores") #tabs the high score to center-ish
    print("--------------------------------------------------------------") #this separates the high score and the player scores. Also, found out that you can't multiply repeat in pycharm like you can in idle
    print(player1+","+score1)#players 1 2 and 3 are printed, then there is space before an equal and then for individual scores
    print(player2+","+score2)
    print(player3+","+score3)
    print("\t") #creates some space for error message because I just did. Don't know why
    print("\t")
    print("\t")
    print(bug1 + " ERROR " + bugscore) #error message cause someone broke the game and the integer counter,
    # resetting it technically to zero, but with highest score








main()